import React from "react";
import "./Css/style.css";
import Container from "./COMPONENTS/Container";


class App extends React.Component {
   render() {
      return (
         <div>
            <Container />
         </div>
      )
   }
}

export default App;
