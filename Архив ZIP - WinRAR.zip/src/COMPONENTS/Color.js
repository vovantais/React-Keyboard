import React from "react";

class Color extends React.Component {

   render() {
      return (
         <div className="Color">
            <div className="ChooseColor">
               <input type="color" id="col" name="head"
                  value="" />
                  <label for="head">Choose color</label>
            </div>
               <p>&#10006;</p>
            </div>
      );
   }
}

export default Color;