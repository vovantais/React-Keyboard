import React from "react";
import Numbers from "./Numbers";
import LetterFirst from "./LettersFirst";
import LetterSecond from "./LettersSecond";
import LetterThird from "./LettersThird";
import Letterlast from "./LettersLast";
import Color from "./Color";

class Flex extends React.Component {
   render() {
      return (
         <div className="Flex" onClick={this.props.event}>
            <div>
               <Numbers />
            </div>
            <div>
               <LetterFirst />
            </div>
            <div>
               <LetterSecond />
            </div>
            <div>
               <LetterThird  />
            </div>
            <div>
               <Letterlast />
            </div>
            <div>
               <Color />
            </div>
         </div>
      );
   }
}

export default Flex;