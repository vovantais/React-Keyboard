import React, { Component } from 'react';
import Textarea from './Textarea';
import Flex from './Flex';

class Container extends React.Component {
   constructor(props) {
      super(props);
      this.state = {
         value: '',
         
      }
   }
   handelClick = (e) => {
      let sumbol = e.target.textContent;
      
      this.setState((prev) => {
         let str = prev.value + sumbol;
         if (sumbol === "Clear"){
            return{
               value: '',
               flag : false,
            }
         }
         if (sumbol === "Tab") {
            return {
               value: '    '+ str.slice(0,-3),
            }
         }
         if (sumbol === "←") {
            return {
               value: str.slice(0, -2),
            }
         }
         if (sumbol === "") {
            return {
               value: str + " " ,
            }
         }
         if (sumbol === "Enter") {
            return {
               value: str.slice(0, -5) + "\n" ,
            }
         }
         if (sumbol === "Select all"){
            return{
               value : str,
            }
         }
         if (sumbol === "⬆ Caps"){
            return{
               value:  str.slice(0, -100) + str.slice(0,-6).toUpperCase(),
            }     
         }
         if (sumbol === "Shift") {
            let s = str.slice(0,-1)
            return {
               value: (str.slice(0, -5) + str.slice(0, -5))
               //str.slice(0,-6).toUpperCase()
            }
         }
         // if (sumbol === "Color") {
         //    
         // }
         // if (this.state.flagCaps) {
         //    sumbol.toLocaleUpperCase();
         //    console.log(sumbol.toLocaleUpperCase());
         // }
         // if (sumbol === "⬆ Caps") {
         //    return {
         //       flagCaps: !!!this.state.flagCaps, 
         //    }
         // }
         // //console.log(this.state.flagCaps);
         // console.log(str);
         return {
            value: str 
         }
      })

      
      
   }
   render() {
      return (
         <div className='Container'>
            <Textarea value={this.state.value} />
            <Flex event={this.handelClick} />
         </div>
      );
   }
}

export default Container;
// ↩