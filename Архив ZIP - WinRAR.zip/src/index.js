import React from "react";
import ReactDOM from "react-dom";
import "./Css/style.css";
import App from "./App";

ReactDOM.render(
		<App/>,
	document.getElementById("root"),
);
